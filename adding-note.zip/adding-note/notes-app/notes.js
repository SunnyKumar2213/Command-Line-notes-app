const fs = require('fs')
const chalk = require('chalk');

const getNotes = () => {
    return 'Your notes...'
}

const addNote = (title, body) => {
    const notes = loadNotes()
    //const duplicateNotes = notes.filter((note) => note.title === title)
    const duplicateNote = notes.find((note) => note.title === title);
    if (!duplicateNote) {
        notes.push({
            title: title,
            body: body
        })
        saveNotes(notes)
        console.log(chalk.green.inverse("New note added"));
    } else {
        console.log(chalk.red.inverse("Note title taken!"));
    }
}
const removeNote = (title) => {
    console.log("remove notes:" + title);
    const notes = loadNotes();
    const removedata = [];
    var isFound = 0;
    const matchNotes = notes.filter((note) => note.title !== title)

    if (notes.length > matchNotes.length) {
        saveNotes(matchNotes);
        console.log(chalk.green.inverse("Note remove successfully"));
    } else {
        console.log(chalk.red.inverse("No note found of this title:notejs"));
    }



}

const saveNotes = (notes) => {
    const dataJSON = JSON.stringify(notes)
    fs.writeFileSync('notes.json', dataJSON)
}

const loadNotes = () => {
    try {
        const dataBuffer = fs.readFileSync('notes.json')
        const dataJSON = dataBuffer.toString()
        return JSON.parse(dataJSON)
    } catch (e) {
        return []
    }
}
const listofNotes = () => {
    //  const dataBuffer = fs.readFileSync('notes.json');
    //const dataJSON = dataBuffer.toString();
    console.log(chalk.green.inverse("Your Notes"));
    const dataArray = loadNotes();
    dataArray.forEach(note => {
        console.log(note.title);
    });
}
const readNotes = (title) => {
    const notesArray = loadNotes();
    const foundData = notesArray.find((note) => note.title === title)
    if (foundData) {
        console.log(chalk.green.inverse("Record found successfully"));
        console.log("title: " + foundData.title);
        console.log("Body: " + foundData.body);
    } else {
        console.log(chalk.red.inverse("No record found"));
    }
}
module.exports = {
    getNotes: getNotes,
    addNote: addNote,
    removeNote: removeNote,
    listofNotes: listofNotes,
    readNotes: readNotes
}