
const event = {
    name: "The Birthday Party",
    getList: ["Sunny", "Parshan", "Bheesham"],
    printGuestList() {
        this.getList.forEach((gestlist) => {
            console.log(gestlist + " is attending " + this.name);
        })
    }
}

event.printGuestList();